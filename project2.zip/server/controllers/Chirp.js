const models = require('../models');

const { Chirp } = models;

const makerPage = (req, res) => {
  Chirp.ChirpModel.findAllChirps((err, docs) => {
    if (err) {
      console.log(err);
      return res.status(400).json({ error: 'An error occurred. Chirps cannot be found.' });
    }

    return res.render('app', { csrfToken: req.csrfToken(), chirps: docs });
  });
};

const makeChirp = (req, res) => {
  if (!req.body.chirp) {
    return res.status(400).json({ error: 'A message needs to be typed before it can be chirped.' });
  }

  const createdDate = new Date(Date.now());

  const dateToString = createdDate.toLocaleString('en-US', { timeZone: 'America/New_York' });

  const chirpData = {
    chirp: req.body.chirp,
    author: req.session.account.username,
    date: dateToString,
    owner: req.session.account._id,
  };

  const newChirp = new Chirp.ChirpModel(chirpData);

  const chirpPromise = newChirp.save();

  chirpPromise.then(() => res.json({ redirect: '/maker' }));

  chirpPromise.catch((err) => {
    console.log(err);

    return res.status(400).json({ error: 'An error occurred. Chirp has not been sent.' });
  });

  return chirpPromise;
};

const getChirps = (request, response) => {
  const req = request;
  const res = response;

  return Chirp.ChirpModel.findAllChirps((err, docs) => {
    if (err) {
      console.log(err);
      return res.status(400).json({ error: 'An error occurred. Chirps cannot be found.' });
    }

    return res.json({ chirps: docs });
  });
};

// POST
const search = (req, res) => {
  if (!req.body.search) {
    return res.status(400).json({ error: 'One or more keywords need to be typed before you can search.' });
  }

  const searchedTerm = req.body.search;

  return Chirp.ChirpModel.findBySearch(searchedTerm, (err, docs) => {
    if (err) {
      console.log(err);
      return res.status(400).json({ error: 'An error occurred. Chirps cannot be found.' });
    }

    return res.json({ chirps: docs });
  });
};

module.exports.makerPage = makerPage;
module.exports.getChirps = getChirps;
module.exports.make = makeChirp;
module.exports.search = search;
