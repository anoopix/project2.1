const handleChirp = (e) => {
    e.preventDefault();

    if ($("#maker").val() == '') {
        handleError("A message needs to be typed before it can be chirped.");
        return false;
    }

    sendAjax('POST', $("#makerForm").attr("action"), $("#makerForm").serialize(), function() {
        loadChirpsFromServer('/getChirps');
    });

    return false;
};

const MakerForm = (props) => {
    return(
    <form id="makerForm" name="chirpForm" onSubmit={handleChirp} action="/maker" method="POST" className="makerForm">
        <textarea id="maker" type="text" name="chirp" rows="5" cols="80" placeholder="Make a chirp"></textarea>
        <input type="hidden" name="_csrf" value={props.csrf} />
        <br/>
        <input id="sendBtn" type="submit" value="Send" />
    </form>
    );
};

const handleSearch = (e) => {

    e.preventDefault();

    if ($("#search").val() == '') {
        handleError("One or more keywords need to be typed in order to search.");
        return false;
    }

    sendAjax('POST', $("#searchForm").attr("action"), $("#searchForm").serialize(), function(data) {
        ReactDOM.render(
            <ChirpList chirps={data.chirps} />,
            document.querySelector(".chirperFeed")
        );
    });

    return false;
};

const SearchForm = (props) => {
    return(
    <form id="searchForm" name="searchForm" onSubmit={handleSearch} action="/search" method="POST" className="searchForm">
        <input id="search" type="text" name="search" placeholder="Search keywords" />
        <input type="hidden" name="_csrf" value={props.csrf} />
        <input id="searchBtn" type="submit" value="Search" />
    </form>
    );
};

const ChirpList = function(props) {
    if(props.chirps.length === 0){
        return(
            <h3 className="noChirps">No Chirps have been posted yet!</h3>
        );
    }

    const chirpNodes = props.chirps.map(function(chirp){
        return(
        <div key={chirp._id} className="chirp">
            <div className="chirpUserInfo">
              <img src="/assets/img/default_avatar.png" alt="default avatar" id="avatar" />
              <p id="authorText">{chirp.author}</p>
            </div>
            <div className="chirpMain">
              <h3 className="chirpText">{chirp.chirp}</h3>
              <h3 className="dateText">Chirped at {chirp.date}</h3>
            </div>
            <div className="chirpInteract">
              <button id="likeBtn">Like</button>
              <button id="rechirpBtn">Rechirp</button>
              <button id="replyBtn">Reply</button>
              <button id="commentsBtn">Comments</button>
            </div>
        </div>
        );
    });

    return(
    <div>
        {chirpNodes}
    </div>
    );
};

const UserForm = (props) => {
    return(
        <div>
            <button onClick={openSettings} id="settingsBtn">
                Account settings
                <input type="hidden" name="_csrf" value={props.csrf} />
            </button>
        </div>
    );
};

const openSettings = (e) => {
    document.querySelector("#settings").style.left = "0";
};

const closeSettings = (e) => {
    document.querySelector("#settings").style.left = "-250px";
};

const SettingsForm = (props) => {
    return(
        <div>
            <a className="closebtn" onClick={closeSettings}>&times;</a>
            <a id="changePassword">Change Password</a>
            <a>Change theme</a>
        </div>
    );
};

const ChangeWindow = (props) => {
    return(
    <form id="changeForm" name="changeForm" onSubmit={handleChange} action="/changePass" method="POST" className="changeForm">
        <div className="labelInputGroup">
            <label htmlFor="old">Old password: </label>
            <input id="old" type="text" name="old" placeholder="old password" />
        </div>
        <div className="labelInputGroup">
            <label htmlFor="pass">New password: </label>
            <input id="new" type="password" name="new" placeholder="password" />
        </div>
        <div className="labelInputGroup">
            <label htmlFor="pass2">Retype password: </label>
            <input id="new2" type="password" name="new2" placeholder="retype password" />
        </div>
        <input type="hidden" name="_csrf" value={props.csrf} />
        <input className="formSubmit" type="submit" value="Sign Up" />
    </form>
    );
};

const createChangeWindow = (csrf) => {
    ReactDOM.render(
        <ChangeWindow csrf={csrf} />,
        document.querySelector(".main")
    );
};

const handleChange = (e) => {
    e.preventDefault();

    if ($("#old").val() == '' || $("#new").val() == '' || $("#new2").val() == '') {
        handleError("All the fields need to be filled!");
        return false;
    }

    if ($("#new").val() !== $("#new2").val()) {
        handleError("The passwords need to match!");
        return false;
    }

    sendAjax('POST', $("#changeForm").attr("action"), $("#changeForm").serialize(), redirect);

    return false;
};

const loadChirpsFromServer = (action) => {
    console.log(action);
    sendAjax('GET', action, null, (data) => {
        ReactDOM.render(
            <ChirpList chirps={data.chirps} />,
            document.querySelector(".chirperFeed")
        );
    });
};

const setup = function(csrf){

    ReactDOM.render(
        <MakerForm csrf={csrf} />, document.querySelector(".makerDiv")
    );

    ReactDOM.render(
        <SearchForm csrf={csrf} />, document.querySelector(".searchDiv")
    );

    ReactDOM.render(
        <ChirpList chirps={[]} />, document.querySelector(".chirperFeed")
    );

    ReactDOM.render(
        <UserForm csrf={csrf} />, document.querySelector(".userContainer")
    );

    ReactDOM.render(
        <SettingsForm csrf={csrf} />, document.querySelector("#settings")
    );

    const changePassword = document.querySelector("#changePassword");

    changePassword.addEventListener("click", (e) => {
        e.preventDefault();
        createChangeWindow(csrf);
        return false;
    });

    loadChirpsFromServer('/getChirps');
};

const getToken = () => {
    sendAjax('GET', '/getToken', null, (result) => {
        setup(result.csrfToken);
    });
};

$(document).ready(function(){
    getToken();
});